# FNB hackathon calculation starter

Pure TypeScript calculations plus a React component for an existing Next.js app.
No LLM, external API, credentials, or extra runtime dependencies.

## Connect to Next.js

Copy `finance.ts` and `FinanceDemo.tsx` into the same directory, for example
`src/components/finance/`. Import the demo in your App Router page:

```tsx
import FinanceDemo from '@/components/finance/FinanceDemo';
export default function Page() { return <FinanceDemo />; }
```

Adapt the alias/path to your app. The calculation module can also be imported
by a server route. Validation throws RangeError; catch it in an API route and
return a 400 response instead of exposing a server error.

## Run the calculation tests

Node 22.13 or newer:

```sh
node --experimental-strip-types --test finance.test.mjs
```

The demo component requires your existing React/Next.js project. Its slider uses
synthetic data and only calculates estimates; it does not initiate payments.

## Contract for teammates

- All money is integer USD cents: $5,000 = 500000.
- Rates are percentages: 24 means 24%, not 0.24.
- Debt uses APR/12 monthly interest with cent rounding, then a month-end payment.
- Savings converts APY to an equivalent monthly rate; deposits occur at month end.
- Default horizon is 1200 months. A null payoff/goal time means no completed
  projection, not zero months. Check status before displaying a result.
- Interest/months saved are null unless both debt scenarios reach payoff.
- Show assumptions with results. These are planning estimates, not issuer statements.
- Money inputs are capped at 1e12 cents, rates at 1000%, horizons at 1200 months;
  these are technical limits, not product terms or suitability judgments.
- A too-low payment returns immediately; totals/schedule only cover simulated months.

## Verification basis and limits

Hand-computed test cases verify monthly interest, partial final payments,
cash conservation, zero rates, APY conversion, unreachable outcomes, and invalid inputs.
Credit cards often use daily/average daily balances, so matching a real card
requires issuer terms, statement dates, transactions, payment timing, and APR buckets.
Savings uses monthly rounding rather than any specific bank's daily accrual method.
Rates are fixed inputs, not current FNB rates. No fees, taxes, changing minimum
payments, rate changes, promotional APRs, or new borrowing are modeled.

CFPB references:
- https://www.consumerfinance.gov/ask-cfpb/how-does-my-credit-card-company-calculate-the-amount-of-interest-i-owe-en-51/
- https://www.consumerfinance.gov/ask-cfpb/what-is-a-daily-periodic-rate-on-a-credit-card-en-46/

Next extension: multiple debts with fixed total payment budget, explicit minimum
payment rules, and rollover when a debt is paid. Agree that input contract with
your team before adding avalanche/snowball comparison.
